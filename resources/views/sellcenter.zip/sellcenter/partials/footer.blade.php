<footer class="main-footer">
    <div class="pull-right hidden-xs">

    </div>
    <strong>  &copy; 2021 <a href="https://bondhonsociety.com">Bondhon Society Limited</a>.</strong> All rights
    reserved.
  </footer>

  <div class="control-sidebar-bg"></div>
